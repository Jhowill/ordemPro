# OrdemPro

App mobile offline-first para gestao de ordens de servico, clientes, equipamentos, pecas, servicos, PDF profissional e backup manual.

## Stack

- Expo SDK 57
- React Native
- TypeScript
- Expo Router
- AsyncStorage local na V1 funcional
- `expo-print` e `expo-sharing` para PDF

## Rodar localmente

```bash
npm install
npm run start
```

Verificacoes:

```bash
npm run typecheck
npm run lint
```

## Fluxos implementados

- Onboarding da empresa
- Home operacional
- Clientes
- Equipamentos
- Catalogo de servicos
- Catalogo de pecas
- Criacao de OS guiada
- Detalhe de OS
- Status da OS
- Calculo de valores
- PDF local profissional
- Compartilhamento de PDF
- Backup JSON manual
- Configuracoes de empresa, PDF, backup e seguranca

## Observacoes

Os documentos em `docs/` continuam sendo a fonte de produto e implementacao. Esta V1 usa persistencia local por AsyncStorage para entregar um app Expo funcional rapidamente; a migracao para SQLite local esta preparada nos documentos e na arquitetura.

