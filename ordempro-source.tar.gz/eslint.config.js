const expoConfig = require('eslint-config-expo/flat');

module.exports = expoConfig;

